
public interface Human {
	String getName();
		
	String getFamilyName();
}
