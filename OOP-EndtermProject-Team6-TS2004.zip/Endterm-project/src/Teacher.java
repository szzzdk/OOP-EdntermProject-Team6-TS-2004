
public class Teacher extends Personal {

	private String subject;
	
    public Teacher(String name, String family_name, int teacherID, String subject){
    	super(name, family_name, teacherID);    
    	this.subject = subject;
    }

    public Teacher() {
	}

	public String getSubject() {
        return subject;
    }
    
    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    @Override
    public String toString() {
        return "Full name of the Teacher: " + getName() + " " + getFamilyName() +
        	   "\nTeacher's ID: " + getID() +
        	   "\nSubject: " + getSubject();
    }
}