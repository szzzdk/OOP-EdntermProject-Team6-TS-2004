import java.util.*;

public class ImplementTeacher extends Teacher{

	public ImplementTeacher(String name, String family_name, int teacherID, String subject){
    	super(name, family_name, teacherID, subject);    
    }
	
	public ImplementTeacher() {
	}
	
	Teacher t1 = new Teacher("Anna", "White", 10001, "Math");
	Teacher t2 = new Teacher("Maria", "Stonks", 10002, "History");
	Teacher t3 = new Teacher("Rakhim", "Mayers", 10003, "Physics");

	
	Scanner sc = new Scanner(System.in);
	
	public void TeacherInfo() throws Exception {	
		try {
			System.out.println("Enter your ID: ");
			int idtest = sc.nextInt();
			if (idtest == t1.getID()) {
				System.out.println(t1.toString());
				}
			else if (idtest == t2.getID()) {
				System.out.println(t2.toString());
				}
			else if (idtest == t3.getID()) {
				System.out.println(t3.toString());
				}
			else {
				throw new Exception("ID is wrong!");
				}
			} catch (Exception e) {	
				throw new Exception("ID is wrong!");
				}
		}
	}
