import java.util.*;
import java.util.List;

public class University {
	
	 private List<Teacher> teachers;
	 private List<Student> students;
	
	 
	 public List<Teacher> getTeachers() {
		 return teachers;
	 }
	 
	 public void addTeacher(Teacher teacher) {
		 teachers.add(teacher);
	 }
	 
	 public List<Student> getStudents() {
		 return this.students;
	 }
	 
	 public void addStudent(Student student) {
		 students.add(student); 
	 }
	 
	 public int getStudentID(Student student) {
		 return student.getID();
	 }
	 
	 public int getTeacherID(Student teacher) {
		 return teacher.getID();
	 }
	 
	 public List<Student> getStudentsFromTheSameGroup(List<Student> students, String group) {
		 List<Student> result = new ArrayList<>();
		 for (Student student : students) {
			 if (student.getGroup().equals(group))
				 result.add(student);
		 }
		 return result;
	 }
	 
//	 public int getStudentsID(List<Student> student) {
//		 for (Student students : student) {
//			 return 0;
//		 }
//	 }
}
