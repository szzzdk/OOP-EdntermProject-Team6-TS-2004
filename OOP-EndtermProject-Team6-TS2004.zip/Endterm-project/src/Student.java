
public class Student extends Personal {

    private int gradeMath;
    private int gradeHistory;
    private int gradePhysics;
    private String group;
    
    public Student(String name, String family_name, int studentID, String group){
    	super(name, family_name, studentID);   
    	this.group = group;
    }
    
    public Student() {
    	
    }
           
    public int getGradeMath() {
        return gradeMath;
    }
    
    public void setGradeMath(int gradeMath) {
        this.gradeMath = gradeMath;
    }
    
    public int getGradeHistory() {
        return gradeHistory;
    }
    
    public void setGradeHistory(int gradeHistory) {
        this.gradeHistory = gradeHistory;
    }
    
    public int getGradePhysics() {
        return gradePhysics;
    }
    
    public void setGradePhysics(int gradePhysics) {
        this.gradePhysics = gradePhysics;
    }
    
    public String getGroup() {
        return group;
    }
    
    public void setGroup(String group) {
        this.group = group;
    }
    
    public void checkGradeMath() {
    	System.out.println("Full name of the Student: " + getName() + " " + getFamilyName() + " Math grade: " + getGradeMath());
    }
    
    public void checkGradePhysics() {
    	System.out.println("Full name of the Student: " + getName() + " " + getFamilyName() + " Physics grade: " + getGradePhysics());
    }
    
    public void checkGradeHistory() {
    	System.out.println("Full name of the Student: " + getName() + " " + getFamilyName() + " History grade: " + getGradeHistory());
}
    
    @Override
    public String toString() {
    	return "Full name of the Student: " + getName() + " " + getFamilyName() +
         	   "	Student's ID: " + getID();
    }    
}
