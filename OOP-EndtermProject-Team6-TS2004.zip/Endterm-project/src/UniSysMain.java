import java.util.*;

public class UniSysMain {

	public static int getRandom(int maximum, int minimum) { 
		return ((int) (Math.random()*(maximum - minimum))) + minimum; 
	}



	public static void main(String[] args) throws Exception{	
		
		List<Teacher> teacherList = new ArrayList<>();		
		Teacher[] teachers = new Teacher[3];		
		teachers[0] = new Teacher("Anna", "White", 10001, "Math");
		teachers[1] = new Teacher("Maria", "Stonks", 10002, "History");
		teachers[2] = new Teacher("Rakhim", "Mayers", 10003, "Physics");
		
		for (int n = 0; n < teachers.length; n++) {
			teacherList.add(teachers[n]);
		}
				
		List<Student> studentList = new ArrayList<>();		
		Student[] students = new Student [5];		
		students[0] = new Student("Moesha", "Stott", 20019, "TS-2001");
		students[1] = new Student("Khloe", "Boyd", 20021, "TS-2001");
		students[2] = new Student("Miah", "Byers", 20033, "TS-2002");
		students[3] = new Student("Stan", "Arias", 20069, "TS-2002");
		students[4] = new Student("Orion", "Bruce", 20017, "TS-2003");
		
		for (int n = 0; n < students.length; n++) {
		students[n].setGradeMath(getRandom(5, 2));
		}
		
		for (int n = 0; n < students.length; n++) {
			students[n].setGradeHistory(getRandom(5, 2));
			}
		
		for (int n = 0; n < students.length; n++) {
			students[n].setGradePhysics(getRandom(5, 2));
			}
		
		for (int n = 0; n < students.length; n++) {
			studentList.add(students[n]);
		}

		
//		University ch1 = new University();
//		System.out.println(ch1.getStudentsID(studentList));
//		System.out.println(ch1.getStudentsID(studentList));	
		
//		for (int n = 0; n < studentList.size(); n++) {
//			System.out.println(ch1.getStudentsID(studentList));
//		}
		
//		for (int n = 0; n < studentList.size(); n++) {
//			System.out.println(studentList.getStudentID(s1));
//		}

		ImplementTeacher teachertest1 = new ImplementTeacher();	
		ImplementStudent studenttest2 = new ImplementStudent();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Are you a Teacher or Student? (Enter T for Teacher; S for student): ");
		String check = sc.nextLine();
		University ch = new University();
		if (check.equals("T")) {
			int swapp = 0;
			String swap = null;
			try {
				System.out.println("Enter your ID: ");
				int idtest = sc.nextInt();
				for(int i = 0; i < teachers.length; i++)  {					
					if (idtest == teachers[i].getID()) {
						swap = teachers[i].toString();
						System.out.println(swap);
						swapp = idtest;
					} 					
					else {
						continue;	
						} 
				}
				
				if (swap == null) {
					throw new Exception("ID is wrong!");
				}
				
			} catch (Exception e) {	
				throw new Exception("ID is wrong!");
			}	
			
			System.out.println("\nSearch by group name or student's ID? (G for group name; S for student's ID; Q to quit): ");
			sc.nextLine();
			String test2 = sc.nextLine();
			if (test2.equals("G")) {
				System.out.println("Enter name of a group: ");
				String test3 = sc.nextLine();
				
				if (test3.equals("TS-2001")) {
					System.out.println("Students of TS-2001: ");
					List<Student> TS2001 = ch.getStudentsFromTheSameGroup(studentList, "TS-2001");
					for (Student student : TS2001) {
						System.out.println(student.toString());
						}					
					System.out.println("Choose one option: " + 
							"\n1 - Check grades;" + "\n2 - Change grades (not working yet)");
					int test3v2 = sc.nextInt();
					if (test3v2 == 1) {
						if(swapp == 10001) {
							for (Student student : TS2001) {
								student.checkGradeMath();
							}
						} else if (swapp == 10002) {
							for (Student student : TS2001) {
								student.checkGradeHistory();
							}
						} else if (swapp == 10003) {
							for (Student student : TS2001) {
								student.checkGradePhysics();
							}
						}
					}
					else if (test3v2 == 2) {
						return;
					}
					
				}
				
				else if (test3.equals("TS-2002")) {
					System.out.println("Students of TS-2002: ");
					List<Student> TS2002 = ch.getStudentsFromTheSameGroup(studentList, "TS-2002");
					for (Student student : TS2002) {
						System.out.println(student.toString());
						}
					System.out.println("Choose one option: " + 
							"\n1 - Check grades;" + "\n2 - Change grades (not working yet)");
					int test3v2 = sc.nextInt();
					if (test3v2 == 1) {
						if(swapp == 10001) {
							for (Student student : TS2002) {
								student.checkGradeMath();
							}
						} else if (swapp == 10002) {
							for (Student student : TS2002) {
								student.checkGradeHistory();
							}
						} else if (swapp == 10003) {
							for (Student student : TS2002) {
								student.checkGradePhysics();
							}
						}
					} 
					else if (test3v2 == 2) {
						return;
					}
				}
				
				else if (test3.equals("TS-2003")) {
					System.out.println("Students of TS-2003: ");
					List<Student> TS2003 = ch.getStudentsFromTheSameGroup(studentList, "TS-2003");
					for (Student student : TS2003) {
						System.out.println(student.toString());
						}
					System.out.println("Choose one option: " + 
							"\n1 - Check grades;" + "\n2 - Change grades (not working yet)");
					int test3v2 = sc.nextInt();
					if (test3v2 == 1) {
						if(swapp == 10001) {
							for (Student student : TS2003) {
								student.checkGradeMath();
							}
						} else if (swapp == 10002) {
							for (Student student : TS2003) {
								student.checkGradeHistory();
							}
						} else if (swapp == 10003) {
							for (Student student : TS2003) {
								student.checkGradePhysics();
							}
						}
					}
					else if (test3v2 == 2) {
						return;
					}
				}
				else {
					throw new Exception("Group name is wrong!");
				}
				
//				System.out.println("Choose one option: " + 
//									"\n1 - Check grades;" + "\n2 - Change grades.");
//				int test3v2 = sc.nextInt();
//				if (test3v2 == 1) {
//					
//					}
				}
				
			
			else if (test2.equals("S")) {
				System.out.println("Enter Student's ID: ");
				int test4 = sc.nextInt();				
				for(int n = 0; n < students.length; n++)  {					
					if (test4 == students[n].getID()) {
					System.out.println(students[n].toString());
					} else 
						continue;					
				}
				

			}
			else if (test2.equals("Q")) {
				return;
			}
		
		}
		else if (check.equals("S")) {
			int swapp = 0;
			String swap = null;
			try {
				System.out.println("Enter your ID: ");
				int idtest = sc.nextInt();
				for(int i = 0; i < students.length; i++)  {					
					if (idtest == students[i].getID()) {
						swap = students[i].toString();
						System.out.println(swap);
						swapp = idtest;
					} 					
					else {
						continue;	
						} 
				}
				
				if (swap == null) {
					throw new Exception("ID is wrong!");
				}
				
			} catch (Exception e) {	
				throw new Exception("ID is wrong!");
			}
			
			System.out.println("Choose one option: " + 
						"\n1 - Check grades;");
			int test3v3 = sc.nextInt();
			if (test3v3 == 1) {
				System.out.println("Pick needed subject: " + 
						"\n1 - Math;" + "\n2 - History;" + "\n1 - Physics.");
				int test3v4 = sc.nextInt();
				if (test3v4 == 1) {
					
					
					
				}
				
			}
			
		}		
	}
}
	
		





	
	

	
	
//}
		
//		System.out.println("Enter Teacher's Name: ");
//		Teacher t2 = new Teacher();
//		t2.setName(sc.nextLine());
//			
//		System.out.println("Enter Teacher's Family Name: ");
//		t2.setFamilyName(sc.nextLine());
//		
//		try {
//		System.out.println("Enter Teacher's ID: ");
//		t2.setID(sc.nextInt());
//		} catch (Exception e) {
//			throw new Exception("ID is wrong!");						
//		} 		
//		
//		System.out.println("Enter Teacher's Subject: ");
//		t2.setSubject(sc.nextLine());
//		t2.setSubject(sc.nextLine());
//		System.out.println(t2.toString());
//		}	
	

