import java.util.*;

public class ImplementStudent extends Student{
	
	public ImplementStudent(String name, String family_name, int teacherID, String group){
//    	super(name, family_name, teacherID, group);    
    }
	
	public ImplementStudent() {
	}
	
//	Student s1 = new Student("Moesha", "Stott", 20019, "TS-2001");
//	Student s2 = new Student("Khloe", "Boyd", 20021, "TS-2001");
//	Student s3 = new Student("Miah", "Byers", 20033, "TS-2002");
//	Student s4 = new Student("Stan", "Arias", 20069, "TS-2002");
//	Student s5 = new Student("Orion", "Bruce", 20017, "TS-2003");
	
	
	
	
}
