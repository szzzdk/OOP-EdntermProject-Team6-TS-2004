
public abstract class Personal implements Human{
    private String name;
    private String family_name;
    private int ID = 0;
 
    public Personal(String name, String family_name, int ID) {
        this.name = name;
        this.family_name = family_name;
        this.ID = ID;
    }
    
    public Personal() {
    	
    }
    
    @Override 
    public String getName() {
        return name;
    }
     
    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public String getFamilyName() {
    	return family_name;
    }
    
    public void setFamilyName(String family_name) {
        this.family_name = family_name;
    }
 
    public int getID() {
        return ID;
    }
 
    public void setID(int ID) {
        this.ID = ID;
    }
}
